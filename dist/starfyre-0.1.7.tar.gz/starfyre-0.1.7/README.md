# Starfyre ⭐🔥

Create reactive frontends using only Python
