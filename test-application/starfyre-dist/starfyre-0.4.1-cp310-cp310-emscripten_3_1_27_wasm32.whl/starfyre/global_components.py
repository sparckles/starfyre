from collections import defaultdict

components = defaultdict(list)
new_global_components = dict()



__all__ = ['components']
