from collections import defaultdict

components = defaultdict(list)



__all__ = ['components']
