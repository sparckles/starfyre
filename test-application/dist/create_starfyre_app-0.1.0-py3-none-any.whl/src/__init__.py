from starfyre import create_component, render

from .counter import Counter
from .display import Display

# from .state import get_state, set_state


def main():
    counter = Counter()
    display = Display()

    render(
        create_component("""
            <counter hello='world'>
                <display>
                    <p>This is a nested child</p>
                </display>
            </counter>
        """)
    )
