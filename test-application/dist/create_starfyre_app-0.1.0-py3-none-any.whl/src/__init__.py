import starfyre
from starfyre import global_components

from .counter import Counter
from .display import Display


def main():
    counter = Counter()
    display = Display()
    print("This is an innovation")
    print("Final not counter", starfyre.create_root_component(
        """<Counter><Display></Display></Counter>"""
    ))
    print(global_components.components["counter"])
    counter.children.append(display)
    print("Final counter", counter)
    starfyre.render(counter, starfyre.js.document.getElementById("root"))
    print(starfyre.sum_as_string(1, 2))
