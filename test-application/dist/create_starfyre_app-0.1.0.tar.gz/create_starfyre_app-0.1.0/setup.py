# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['src']

package_data = \
{'': ['*']}

install_requires = \
['starfyre>0.3.0']

setup_kwargs = {
    'name': 'create-starfyre-app',
    'version': '0.1.0',
    'description': '',
    'long_description': '# create-starfyre-app\n\nThis is a very basic implementation Right now.\n\nThe steps to run:\n1. `npm run start` - this will build the custom src file as a package and then start an http server\n2. Go to `http://localhost:8000/public` to see the file\n\n',
    'author': 'Sanskar Jethi',
    'author_email': 'sansyrox@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
