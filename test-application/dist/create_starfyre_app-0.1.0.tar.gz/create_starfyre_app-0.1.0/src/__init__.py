import starfyre
from .header import Body

def main():
    starfyre.main()
