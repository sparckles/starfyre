# create-starfyre-app

This is a very basic implementation Right now.

The steps to run:
1. `npm run start` - this will build the custom src file as a package and then start an http server
2. Go to `http://localhost:8000/public` to see the file

